import { Component } from "react";

class StepTwo extends Component{
    constructor(props){
        super();
        this.state = {
            playFile:''
        }
    }

    calculateDepressionSeverityLetter = (score)=>{
        let levelLetter = 'L';
        if(score <= 9)
            levelLetter='L'
        if(score >=10)
            levelLetter='M'
        if(score >=15)
            levelLetter = "H"
        return levelLetter;
    }

    componentDidMount(){

    }

    render(){
        return(
            <div style={{ 
                display: 'table', 
                marginLeft: 'auto', 
                marginRight: 'auto' 
              }}>
                <div style={{
                  width:(1068)
                }}>
          
                  <div style={{
                    paddingBottom:16,
                    paddingTop:16,
                  }}>
                    <div style={{
                      fontSize:'1.3em',
                      fontWeight: 'bold',
                      color: '#23286b',
                      paddingLeft:79,
          
                    }}> 
                      ✦ My Mind Radio
                    </div>
                  </div>
                  <div style = {{
                  }}>
                    <div style={{
                      backgroundColor:'white',
                    }}>
                      <div style={{
                        fontSize:'30px',
                        fontWeight: 'bold',
                        color: '#f1b522',
                        paddingLeft:79,
                        paddingTop:50,
                        fontFamily: 'Times New Roman',
                      }}> 
                        Your radio station is set.<br/>
                        Enjoy.
                        {/*<br></br> 는 <br/>과 같음*/}
                        
                      <div style={{
                        paddingBottom:16,
                        paddingTop:16,
                      }}>
                        <div style={{
                          display:"table",
                        }}> 
                        <iframe width="320" height="240" src="https://www.youtube.com/embed/iDjQSdN_ig8" frameborder="0" allow="accelerometer; autoplay; encrypted-media; gyroscope; picture-in-picture" allowfullscreen>
                        </iframe>
                        </div>
                       </div>  
                      </div>
                      <div style={{  
                        float: 'right',
                      }}> 
                        <img width = '30%' src="radio.png" marginLeft = '500px'></img>
                      </div>
                      
                      
                    </div>
                    
                    
                  </div>
                
                </div>
              </div>
        )
    }
}

export default StepTwo;